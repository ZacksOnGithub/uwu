import discord
import random  
import datetime
import asyncio
from discord.ext import commands
from discord.ui import Button, View

class Responder(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author == self.bot.user:
            return

        # Fun Commands
        if message.content.startswith("m!calculate"):
         answer = eval(message.content[len("m!calculate"):].strip())
         await message.channel.send(f"The answer is {answer}")
      
        if message.content.startswith("m!say"):
            await message.delete()
            content = message.content[len("m!say"):].strip()
            await message.channel.send(content)

        if message.content.startswith("m!8ball"):
            choices = ["Yes", "Maybe", "No", "Probably", "Probably not", "I don't know", "Ask again later"]
            content = message.content[len("m!8ball"):].strip()
            await message.channel.send(f"Question: {content}\nAnswer: {random.choice(choices)}")

        if message.content.startswith("m!rate"):
            choices = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]
            content = message.content[len("m!rate"):].strip()
            await message.channel.send(f"You have been rated a {random.choice(choices)}")

        if message.content.startswith("m!flip"):
            choices = ["Heads", "Tails"]
            content = message.content[len("m+!flip"):].strip()
            await message.channel.send(f"You flipped a {random.choice(choices)}")

        if message.content.startswith("m!roll"):
            choices = ["1", "2", "3", "4", "5", "6"]
            content = message.content[len("m!roll"):].strip()
            await message.channel.send(f"You rolled a {random.choice(choices)}")

        if message.content.startswith("m!guess"):
            choices = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]
            content = message.content[len("m+!guess"):].strip()

            if choices == content:
                await message.channel.send(f"You got it right! {content}")
            else:
                await message.channel.send(f"You guessed {content}. Correct Answer: {random.choice(choices)}")

        # Moderation Commands
        if message.content.startswith("m!promote"):
          if message.author.guild_permissions.administrator:
              mentioned_user = message.mentions[0] if message.mentions else None
              content = message.content[len("m!promote"):].strip()
              content_parts = content.split("|")
              if len(content_parts) >= 4 and mentioned_user:
                  reason = content_parts[0].strip()
                  new_rank = content_parts[1].strip()
                  old_rank = content_parts[2].strip()
                  notes = content_parts[3].strip() if len(content_parts) >= 5 else ""
                  emb = discord.Embed(title="Promotion", description="Congratulations on your promotion!", timestamp=time)
                  emb.add_field(name="User", value=mentioned_user.mention, inline=False)
                  emb.add_field(name="Reason", value=reason, inline=False)
                  emb.add_field(name="New Rank", value=new_rank, inline=False)
                  emb.add_field(name="Old Rank", value=old_rank, inline=False)
                  if notes:
                      emb.add_field(name="Notes", value=notes, inline=False)
                  emb.set_author(icon=message.author.avatar.url, name=message.author.name)
                  emb.set_thumbnail(url=message.guild.icon)
                  await message.delete()
                  await message.channel.send(embed=emb)

        if message.content.startswith("m!demote"):
          if message.author.guild_permissions.administrator:
              mentioned_user = message.mentions[0] if message.mentions else None
              content = message.content[len("m!demote"):].strip()
              content_parts = content.split(" ")
              if len(content_parts) >= 4 and mentioned_user:
                  reason = content_parts[0].strip()
                  new_rank = content_parts[1].strip()
                  old_rank = content_parts[2].strip()
                  notes = content_parts[3].strip() if len(content_parts) >= 5 else ""
                  emb = discord.Embed(title="Demotion", description="We regret to inform you of your demotion.", timestamp=time)
                  emb.add_field(name="User", value=mentioned_user.mention, inline=False)
                  emb.add_field(name="Reason", value=reason, inline=False)
                  emb.add_field(name="New Rank", value=new_rank, inline=False)
                  emb.add_field(name="Old Rank", value=old_rank, inline=False)
                  if notes:
                      emb.add_field(name="Notes", value=notes, inline=False)
                  emb.set_author(icon=message.author.avatar.url, name=message.author.name)
                  emb.set_thumbnail(url=message.guild.icon)
                  await message.delete()
                  await message.channel.send(embed=emb)

      
        if message.content.startswith("m!lock"):
            if message.author.guild_permissions.administrator:
                channel = message.content[len("m!lock"):].strip()
                await message.delete()
                await message.channel.send("<:Lock:1224439018352017460> | Channel Locked!")
                await message.channel.set_permissions(message.guild.default_role, send_messages=False)
            else:
                await message.channel.send("❌ | You do not have permission to use this command.")

        if message.content.startswith("m!unlock"):
            if message.author.guild_permissions.administrator:
                channel = message.content[len("m!unlock"):].strip()
                await message.delete()
                await message.channel.send("🔓 | Channel Unlocked!")
                await message.channel.set_permissions(message.guild.default_role, send_messages=True)
            else:
                await message.channel.send("❌ | You do not have permission to use this command.")

        if message.content.startswith("m!purge"):
            if message.author.guild_permissions.administrator:
                await message.delete()
                content = message.content[len("m!purge"):].strip()
                try:
                    limit = int(content)
                except ValueError:
                    await message.channel.send("❌ | Please provide a valid number for purging messages")
                    return

                await message.channel.send(f"🔃 | Purging {limit} messages")
                deleted = await message.channel.purge(limit=limit)
                await message.channel.send(f"✅ | Successfully purged {len(deleted)} messages")
            else:
                await message.channel.send("❌ | You do not have permission to use this command")

        if message.content.startswith("m!nick"):
          if message.author.guild_permissions.administrator:
              await message.delete()
              mentioned_user = message.mentions[0] if message.mentions else None
              if mentioned_user:
                  nick = message.content[len("m!nick"):].strip()
                  if len(nick) > 32:
                      await message.channel.send("❗ | Nickname must be 32 characters or fewer.")
                  else:
                      await message.channel.send(f"👥 | Nickname added to {mentioned_user.mention}")
                      await mentioned_user.edit(nick=nick)
              else:
                  await message.channel.send("❌ | You need to mention a user.")
          else:
              await message.channel.send("❌ | You do not have permission to use this command.")

        if message.content.startswith("m!warn"):
            if message.author.guild_permissions.administrator:
                await message.delete()
                content = message.content[len("m+!warn"):].strip()
                mentioned_user = message.mentions[0] if message.mentions else None
                if mentioned_user:
                    await message.channel.send(f"{mentioned_user.mention} has been warned successfully!")
                    emb = discord.Embed(title="🛡 | Member Warned!", description=f"You have been warned in {message.guild.name} for {content}")
                    emb.timestamp = datetime.datetime.utcnow()
                    await mentioned_user.send(embed=emb)
                else:
                    await message.channel.send("You need to mention a user to warn.")
            else:
                await message.channel.send("❌ | You cannot use this command!", ephemeral=True)

        if message.content.startswith("m!kick"):
            if message.author.guild_permissions.administrator:
                await message.delete()
                content = message.content[len("m+!kick"):].strip()
                mentioned_user = message.mentions[0] if message.mentions else None
                if mentioned_user:
                    await message.channel.send(f"{mentioned_user.mention} has been kicked successfully!")
                    emb = discord.Embed(title="🛡 | Member Kicked!", description=f"You have been kicked in {message.guild.name} for {content}")
                    emb.timestamp = datetime.datetime.utcnow()
                    await mentioned_user.send(embed=emb)
                    await mentioned_user.kick(reason=content)
                else:
                    await message.channel.send("You need to mention a user to kick.")
            else:
                await message.channel.send("❌ | You cannot use this command!", ephemeral=True)

        if message.content.startswith("m!ban"):
            if message.author.guild_permissions.administrator:
                await message.delete()
                content = message.content[len("m+!ban"):].strip()
                mentioned_user = message.mentions[0] if message.mentions else None
                if mentioned_user:
                    await message.channel.send(f"{mentioned_user.mention} has been banned successfully!")
                    emb = discord.Embed(title="🛡 | Member Banned!", description=f"You have been banned in {message.guild.name} for {content}")
                    emb.timestamp = datetime.datetime.utcnow()
                    await mentioned_user.send(embed=emb)
                    await mentioned_user.ban(reason=content)
                else:
                    await message.channel.send("You need to mention a user to ban.")
            else:
                await message.channel.send("❌ | You cannot use this command!", ephemeral=True)

        # Information Commands
        if message.content.startswith("m!info User"):
            user_mention = message.content[len("m+!info User"):].strip()
            user_id = int(user_mention.strip("<!@>"))
            user = self.bot.get_user(user_id)
            if user:
                emb = discord.Embed()
                emb.title = "User Info"
                emb.description = f"Here is the info we retrieved about {user}"
                emb.add_field(name="Username", value=f"`{user.name}`", inline=False)
                emb.add_field(name="User ID", value=f"`{user.id}`", inline=False)
                emb.add_field(name="User Status", value=f"`{user.status}`", inline=False)
                emb.add_field(name="Mutual Servers", value=f"`{len(user.mutual_guilds)}`", inline=False)
                emb.add_field(name="Joined At", value=f"`{user.joined_at}`", inline=False)
                emb.add_field(name="Created At", value=f"`{user.created_at}`", inline=False)
                emb.timestamp = datetime.datetime.utcnow()
                await message.channel.send(embed=emb)
            else:
                await message.channel.send("User not found.")

        if message.content.startswith("m!info Server"):
            guild = message.guild
            emb = discord.Embed()
            emb.title = "Server Info"
            emb.description = f"Here is the information we received about {guild.name}"
            emb.add_field(name="Server Name", value=f"`{guild.name}`", inline=False)
            emb.add_field(name="Server ID", value=f"`{guild.id}`", inline=False)
            emb.add_field(name="Server Owner", value=f"`{guild.owner}`", inline=False)
            emb.add_field(name="Channel Count", value=f"Text: `{len(guild.text_channels)}` | VC: `{len(guild.voice_channels)}`", inline=False)
            emb.timestamp = datetime.datetime.utcnow()
            await message.channel.send(embed=emb)

        if message.content.startswith("m!info Bot"):
            emb = discord.Embed()
            emb.title = "Bot Info"
            emb.description = f"Here is the information about {self.bot.user.name}"
            emb.add_field(name="Bot Name", value=f"`{self.bot.user.name}`", inline=False)
            emb.add_field(name="Bot ID", value=f"`{self.bot.user.id}`", inline=False)
            emb.add_field(name="Bot Status", value=f"`{self.bot.user.status}`", inline=False)
            emb.timestamp = datetime.datetime.utcnow()
            await message.channel.send(embed=emb)

        if message.content.startswith("m!ping"):
            await message.channel.send(f"{round(self.bot.latency * 1000)}ms")

def setup(bot):
    bot.add_cog(Responder(bot))