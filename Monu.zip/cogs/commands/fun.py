import discord
import random
from discord.ext import commands
from discord.commands.core import slash_command, Option

class Fun(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @slash_command(description="Send a message")
    async def say(self, ctx, message: Option(str, "The message you wanted to send"), embeded: Option(str, "Do you want to send the message as an embed?", choices=["Yes", "No"])):
        if embeded == "Yes":
            embed = discord.Embed(title="Message!", description=message, color=0x00ff00)
            await ctx.respond(embed=embed)
        else:
            await ctx.respond(message)

    @slash_command(description="Rolls a dice")
    async def roll(self, ctx):
        choices = ["1", "2", "3", "4", "5", "6"]
        rolled_number = random.choice(choices)
        await ctx.respond(f"You rolled a {rolled_number}")

    @slash_command(description="Rate yourself")
    async def rate(self, ctx):
        choices = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]
        rated_number = random.choice(choices)
        await ctx.respond(f"You have been rated a {rated_number}")

    @slash_command(description="Flip a coin")
    async def flip(self, ctx):
        choices = ["Heads", "Tails"]
        flipped_number = random.choice(choices)
        await ctx.respond(f"You flipped a  {flipped_number}")

    @slash_command(description="Guess the number")
    async def guess(self, ctx, guess: Option(str, "The guess (1-10)")):
        choices = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]
        guessed_number = random.choice(choices)
        if guess == guessed_number:
            await ctx.respond(f"You got it right! {guessed_number}")
        else:
            await ctx.respond(f"You got it wrong! Right Number: {guessed_number}")

def setup(bot):
    bot.add_cog(Fun(bot))
