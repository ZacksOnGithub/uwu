import discord
from discord.ext import commands
from discord.commands.core import slash_command, Option
from discord.ui import Button, View

class Choice(commands.Cog):
      def __init__(self, bot):
          self.bot = bot

      @slash_command(description="Setup a ticket system")
      async def ticketsetup(self, ctx, 
                            channel_embed_title: Option(str, "The title of the embed in the support channel"), 
                            channel_embed_description: Option(str, "The description of the embed in the support channel"), 
                            channel_embed_color: Option(str, "The color of the embed in the support channel", 
                                                        choices=["Red", "Green", "Blue", "Yellow", "Orange", "Purple"]), 
                            support_role: Option(discord.Role, "The support role"), 
                            support_channel: Option(discord.TextChannel, "The support channel")):
          if ctx.author.guild_permissions.administrator:
              # Map color choices to discord.Color objects
              colors = {
                  "Red": discord.Color.red(),
                  "Green": discord.Color.green(),
                  "Blue": discord.Color.blue(),
                  "Yellow": discord.Color.yellow(),
                  "Orange": discord.Color.orange(),
                  "Purple": discord.Color.purple(),
              }

              # Get the selected color
              color = colors.get(channel_embed_color)

              # Create the embed for the support channel
              embed = discord.Embed(title=channel_embed_title, description=channel_embed_description, color=color)
              await support_channel.send(embed=embed)

              # Create the view with buttons
              view = View()
              create_button = Button(label="Create Ticket", style=discord.ButtonStyle.green)
              view.add_item(create_button)

              # Send the view to the support channel
              message = await support_channel.send("Support Ticket", view=view)

              # Button callback
              @create_button.callback
              async def create_button_callback(interaction):
                  ticket_channel = await ctx.guild.create_text_channel(f"ticket-{interaction.user.name}")
                  await ticket_channel.set_permissions(ctx.guild.default_role, send_messages=False)
                  await ticket_channel.set_permissions(interaction.user, send_messages=True)
                  await ticket_channel.set_permissions(support_role, send_messages=True)
                  await support_channel.send(f"Ticket created by {interaction.user.mention} in {ticket_channel.mention}")

                  # Add claim and close buttons to the ticket channel
                  claim_button = Button(label="Claim", style=discord.ButtonStyle.green)
                  close_button = Button(label="Close", style=discord.ButtonStyle.red)
                  view = View()
                  view.add_item(claim_button)
                  view.add_item(close_button)
                  await ticket_channel.send("Support Ticket", view=view)

                  # Claim button callback
                  @claim_button.callback
                  async def claim_button_callback(interaction):
                      await ticket_channel.send(f"{interaction.user.mention} has claimed this ticket.")

                  # Close button callback
                  @close_button.callback
                  async def close_button_callback(interaction):
                      await ticket_channel.send(f"{interaction.user.mention} has closed this ticket.")

      @slash_command(description="Setups a verification system")
      async def verifysetup(
          self,
          ctx,
          title: Option(str, description="The title of the embed"),
          description: Option(str, description="The description for the embed"),
          verified_role: Option(discord.Role, description="The verified role"),
          channel: Option(discord.TextChannel, description="The channel that the verification system embed will be sent to")
      ):
          if ctx.author.guild_permissions.administrator:
              emb = discord.Embed(title=f"{title}", description="", color=discord.Color.green())
              emb.add_field(name=" ", value=description)

              button = Button(
                  label="Verify",
                  style=discord.ButtonStyle.green,
                  emoji="✅"
              )

              async def button_callback(interaction: discord.Interaction):
                  user = interaction.user
                  guild = interaction.guild
                  member = guild.get_member(user.id)

                  if member:
                      await member.add_roles(verified_role)
                      await interaction.response.send_message("You have been verified!", ephemeral=True)
                  else:
                      print("Member not found.")

              button.callback = button_callback

              view = View()
              view.add_item(button)

              try:
                  await channel.send(embed=emb, view=view)
              except discord.HTTPException:
                  await ctx.respond("Failed to send verification message. Please check bot permissions.")

          else:
              await ctx.respond("You don't have permission to set up verification.")

      @slash_command(description="Setups a self role system")
      async def selfrolesetup(
          self,
          ctx,
          title: Option(str, description="The title of the embed"),
          description: Option(str, description="The description for the embed"),
          buttons: Option(int, description="The amount of buttons on the embed", choices=["1", "2", "3", "4", "5"]),
          selfrole1: Option(discord.Role, description="The first self role"),
          selfrole2: Option(discord.Role, description="The second self role", default=None),
          selfrole3: Option(discord.Role, description="The third self role", default=None),
          selfrole4: Option(discord.Role, description="The fourth self role", default=None),
          selfrole5: Option(discord.Role, description="The fifth self role", default=None)
      ):
          if ctx.author.guild_permissions.administrator:
              emb = discord.Embed(title=title, description=description, color=discord.Color.green())
              buttons_list = [selfrole1, selfrole2, selfrole3, selfrole4, selfrole5][:int(buttons)]

              view = View()
              for idx, button_role in enumerate(buttons_list):
                  if button_role:
                      button = Button(
                          label=button_role.name,
                          style=discord.ButtonStyle.primary,
                          custom_id=f"selfrole_{idx+1}"
                      )
                      view.add_item(button)

              try:
                  await ctx.send(embed=emb, view=view)
              except discord.HTTPException:
                  await ctx.respond("Failed to send self-role setup message. Please check bot permissions.")

def setup(bot):
      bot.add_cog(Choice(bot))
