import discord
import time
from discord.ext import commands
import random
from discord.commands.core import slash_command, Option

class Info(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.start_time = None

    @commands.Cog.listener()
    async def on_ready(self):
        self.start_time = time.time()
        print("Bot is ready. Start time set:", self.start_time)

    def get_uptime(self):
        uptime_seconds = round(time.time() - self.start_time)
        uptime_str = str(datetime.timedelta(seconds=uptime_seconds))
        return uptime_str

    @slash_command(description="Info Choice")
    async def infochoice(self, ctx, choices: Option(str, "The info type you want!", choices=["User", "Server", "Bot"]), user: Option(discord.Member, "The member you want info about", required=False)):
        emb = discord.Embed(color=0x2F3136)  # Initialize the embed
        if choices == "User":
            if user is None:
                await ctx.respond("Please provide a user to get information about.")
                return
            emb.title = "User Info"
            emb.description = f"Here is the info we retrieved about {user}"
            emb.add_field(name="Username", value=f"`{user}`", inline=False)
            emb.add_field(name="User ID", value=f"`{user.id}`", inline=False)
            emb.add_field(name="User Status", value=f"`{user.status}`", inline=False)
            emb.add_field(name="Mutual Servers", value=f"`{len(user.mutual_guilds)}`", inline=False)
            emb.add_field(name="Joined At", value=f"`{user.joined_at}`", inline=False)
            emb.add_field(name="Created At", value=f"`{user.created_at}`", inline=False)
            await ctx.respond(embed=emb)
        elif choices == "Server":
            emb.title = "Server Info"
            emb.description = f"Here is the information we received about {ctx.guild.name}"
            emb.add_field(name="Server Name", value=f"`{ctx.guild.name}`", inline=False)
            emb.add_field(name="Server ID", value=f"`{ctx.guild.id}`", inline=False)
            emb.add_field(name="Server Owner", value=f"`{ctx.guild.owner}`", inline=False)
            emb.add_field(name="Channel Count", value=f"Text: `{len(ctx.guild.text_channels)}` | VC: `{len(ctx.guild.voice_channels)}`", inline=False)
            await ctx.respond(embed=emb)
        elif choices == "Bot":
            emb.title = "Bot Info"
            emb.description = f"Here is the information about {self.bot.user.name}"
            emb.add_field(name="Bot Name", value=f"`{self.bot.user.name}`", inline=False)
            emb.add_field(name="Bot ID", value=f"`{self.bot.user.id}`", inline=False)
            emb.add_field(name="Bot Servers", value=f"`{len(self.bot.guilds)}` servers", inline=False)
            if self.start_time is not None:
                # Calculate and format bot uptime
                uptime_seconds = time.time() - self.start_time
                uptime_formatted = format_seconds(uptime_seconds)
                emb.add_field(name="Bot Uptime", value=uptime_formatted, inline=False)
                await ctx.respond(embed=emb)

    @slash_command(description="Shows the bot's latency")
    async def ping(self, ctx):
        await ctx.respond(f"🏓 Pong! {round(self.bot.latency * 1000)}ms")

def format_seconds(seconds):
    days = seconds // (24 * 3600)
    seconds %= (24 * 3600)
    hours = seconds // 3600
    seconds %= 3600
    minutes = seconds // 60
    return f"{days} days, {hours} hours, {minutes} minutes"

def setup(bot):
    bot.add_cog(Info(bot))
