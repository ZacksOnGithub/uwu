import discord
from discord.ext import commands
from discord.commands.core import slash_command, Option
import datetime  # Import datetime module for getting current time

class Mod(commands.Cog):

    def __init__(self, bot):
        self.bot = bot

    @slash_command(description="Warns a member")
    async def warn(self, ctx, user: Option(discord.Member,
                                           "The member you want to warn"),
                   reason: Option(str, "The reason for the warn")):
        if ctx.author.guild_permissions.administrator:
            await ctx.respond("🛡 | Member warned successfully!")
            emb = discord.Embed(
                title="Member Warned!",
                description=f"You have been warned in {ctx.guild.name} for {reason}")
            emb.timestamp = datetime.datetime.utcnow()  # Set timestamp to current UTC time
            await user.send(embed=emb)
        else:
            await ctx.respond("❌ | You do not have permission to use this command",
                              ephemeral=True)

    @slash_command(description="Unwarns a member")
    async def unwarn(self, ctx, user: Option(discord.Member,
                                             "The member you want to unwarn"),
                     reason: Option(str, "The reason for the unwarn")):
        if ctx.author.guild_permissions.administrator:
            await ctx.respond("🛡 | Member unwarned successfully!")
            emb = discord.Embed(
                title="Member Unwarned!",
                description=f"You have been unwarned in {ctx.guild.name} for {reason}"
            )
            emb.timestamp = datetime.datetime.utcnow()
            await user.send(embed=emb)

    @slash_command(description="Kicks a member")
    async def kick(self, ctx, user: Option(discord.Member,
                                           "The member you want to kick"),
                   reason: Option(str, "The reason for the kick")):
        if ctx.author.guild_permissions.administrator:
            await ctx.respond("🛡 | Member kicked successfully!")
            emb = discord.Embed(
                title="Member Kicked!",
                description=f"You have been kicked in {ctx.guild.name} for {reason}")
            emb.timestamp = datetime.datetime.utcnow()
            await user.send(embed=emb)
            await user.kick(reason=reason)
        else:
            await ctx.respond("❌ | You do not have permission to use this command",
                              ephemeral=True)

    @slash_command(description="Unkicks a member")
    async def unkick(self, ctx, user: Option(str,
                                             "The member you want to unkick"),
                     reason: Option(str, "The reason for the unkick")):
        if ctx.author.guild_permissions.administrator:
            await ctx.respond("🛡 | Member unkicked successfully!")
            emb = discord.Embed(
                title="Member Unkicked!",
                description=f"You have been unkicked in {ctx.guild.name} for {reason}"
            )
            emb.timestamp = datetime.datetime.utcnow()
            await user.send(embed=emb)
            await user.unkick(reason=reason)
        else:
            await ctx.respond("❌ | You do not have permission to use this command",
                              ephemeral=True)

    @slash_command(description="Bans a member")
    async def ban(self, ctx, user: Option(discord.Member,
                                          "The member you want to ban"),
                  reason: Option(str, "The reason for the ban")):
        if ctx.author.guild_permissions.administrator:
            await ctx.respond("🛡 | Member banned successfully!")
            emb = discord.Embed(
                title="Member Banned!",
                description=f"You have been banned in {ctx.guild.name} for {reason}")
            emb.timestamp = datetime.datetime.utcnow()
            await user.send(embed=emb)
            await user.ban(reason=reason)
        else:
            await ctx.respond("❌ | You do not have permission to use this command",
                              ephemeral=True)

    @slash_command(description="Unbans a member")
    async def unban(self, ctx, user: Option(discord.Member,
                                            "The member you want to unban"),
                    reason: Option(str, "The reason for the unban")):
        if ctx.author.guild_permissions.administrator:
            await ctx.respond("🛡 | Member unbanned successfully!")
            emb = discord.Embed(
                title="Member Unbanned!",
                description=f"You have been unbanned in {ctx.guild.name} for {reason}"
            )
            emb.timestamp = datetime.datetime.utcnow()
            await user.send(embed=emb)
            await user.unban(reason=reason)
        else:
            await ctx.respond("❌ | You do not have permission to use this command",
                              ephemeral=True)

    @slash_command(description="Purges x amount of messages")
    async def purge(self, ctx,
                    amount: Option(int,
                                   "The amount of messages you want to purge")):
        if ctx.author.guild_permissions.administrator:
            await ctx.respond(f"🔃 | Purging {amount} messages", ephemeral=True)
            await ctx.channel.purge(limit=amount)
        else:
            await ctx.respond("❌ | You do not have permission to use this command",
                              ephemeral=True)

    @slash_command(description="Locks a channel")
    async def lock(self, ctx, channel: Option(discord.TextChannel,
                                              "The channel you want to lock")):
        if ctx.author.guild_permissions.administrator:
            await ctx.respond("<:Lock:1224439018352017460> | Channel Locked!")
            await ctx.channel.set_permissions(ctx.guild.default_role,
                                              send_messages=False)

        else:
            await ctx.respond("❌ | You do not have permission to use this command")

    @slash_command(description="Unlocks a channel")
    async def unlock(self, ctx, channel: Option(discord.TextChannel,
                                                "The channel you want to unlock")):
        if ctx.author.guild_permissions.administrator:
            await ctx.respond("🔓 | Channel Unlocked!")
            await ctx.channel.set_permissions(ctx.guild.default_role,
                                              send_messages=True)

        else:
            await ctx.respond("❌ | You do not have permission to use this command")

    @slash_command(description="View recently deleted messages")
    async def snipe(self, ctx):
        if ctx.author.guild_permissions.administrator:
            try:
                contents, author, channel_name, time = self.bot.sniped_messages[
                    ctx.guild.id]
            except:
                await ctx.respond("Couldn't find a message to snipe!")
                return

            embed = discord.Embed(description=contents,
                                  color=discord.Color.purple(),
                                  timestamp=time)
            embed.set_author(name=f"{author.name}#{author.discriminator}",
                             icon_url=author.avatar.url)
            embed.set_footer(text=f"Deleted in : #{channel_name}")

            await ctx.respond(embed=embed)

        else:
            await ctx.respond("❌ | You do not have permission to use this command")

    @slash_command(description="Timeout a member")
    async def timeout(self, ctx, user: Option(discord.Member,
                                              "The member you want to timeout"),
                      reason: Option(str, "The reason for the timeout"), time: Option(int, "The time you want to timeout the member for")):
        if ctx.author.guild_permissions.administrator:
            await ctx.respond("🛡 | Member timed out successfully!")
            emb = discord.Embed(title="Member Timed Out!",
                                description=f"You have been timed out in {ctx.guild.name} for {reason}")
            emb.add_field(name="Time", value=f"{time}")
            emb.timestamp = datetime.datetime.utcnow()
            await ctx.user.send(embed=emb)
            await user.timeout(reason=reason, until=time)

        else:
            await ctx.respond("❌ | You do not have permission to use this command")

    @slash_command(description="Untimeout a member")
    async def untimeout(self, ctx, user: Option(discord.Member,
                                                "The member you want to untimeout"), reason: Option(str, "The reason for the timeout")):
        if ctx.author.guild_permissions.administrator:
            await ctx.respond("🛡 | Member untimed out successfully!")
            emb = discord.Embed(title="Member Untimed Out!",
                                description=f"You have been untimed out in {ctx.guild.name} for {reason}")
            emb.timestamp = datetime.datetime.utcnow()
            await ctx.user.send(embed=emb)
            await user.untimeout(reason=reason)

        else:
            await ctx.respond("❌ | You do not have permission to use this command")

    @slash_command(description="Adds a nickname to a person")
    async def nick(self, ctx, user: Option(discord.Member, "The user you want to nickname"), nickname: Option(str, "The nickname you want to change")):
       await ctx.respond(f"👥 | Nickname changed for {user.mention} to {nickname}")

    @slash_command(description="Manage another person's role")
    async def managerole(self, ctx, user: Option(discord.Member, "The member you want to manage the role for"),
                         role: Option(discord.Role, "The role you want to manage"),
                         option: Option(str, "Add or Remove", choices=["Add", "Remove"])):
        if ctx.author.guild_permissions.administrator:
            if option == "Add":
                await ctx.respond("🛡 | Role added successfully!")
                await user.add_roles(role)
            else:
                await ctx.respond("🛡 | Role removed successfully!")
                await user.remove_roles(role)

        else:
            await ctx.respond("❌ | You do not have permission to use this command")


def setup(bot):
    bot.add_cog(Mod(bot))
