import discord
from discord.commands.core import slash_command
import asyncio
from discord.ext import commands

class Feedback(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.slash_command(description="Leave feedback to maybe help us")
    async def feedback(self, ctx):
        await ctx.respond("Loading...")

        # Create the initial message with instructions
        message_content = "Please leave your feedback below:"
        feedback_message = await ctx.channel.send(message_content)

        # Define a check function for the wait_for function
        def check(msg):
            return msg.author == ctx.author and msg.channel == ctx.channel

        # Wait for the user's feedback message
        try:
            feedback = await self.bot.wait_for("message", timeout=120.0, check=check)
        except asyncio.TimeoutError:
            await ctx.channel.send("You took too long to provide feedback.")
            return

        # Get the feedback channel from the guild
        feedback_channel = discord.utils.get(ctx.guild.channels, name="feedback")

        # Check if the feedback channel exists
        if feedback_channel:
            # Send the feedback to the feedback channel
            await feedback_channel.send(f"Feedback from {ctx.author}: {feedback.content}")
            await ctx.channel.send("Thank you for your feedback! It has been submitted.")
        else:
            await ctx.channel.send("The feedback channel does not exist. Please contact the server administrator.")

    @slash_command(description="Suggest a developement suggestion!")
    async def suggest(self, ctx):
      await ctx.respond("Loading...")

      # Create the initial message with instructions
      message_content = "Please leave your suggestion below:"
      feedback_message = await ctx.channel.send(message_content)

      # Define a check function for the wait_for function
      def check(msg):
          return msg.author == ctx.author and msg.channel == ctx.channel

      # Wait for the user's feedback message
      try:
          feedback = await self.bot.wait_for("message", timeout=120.0, check=check)
      except asyncio.TimeoutError:
          await ctx.channel.send("You took too long to provide feedback.")
          return

      # Get the feedback channel from the guild
      feedback_channel = discord.utils.get(ctx.guild.channels, name="suggestions2")

      # Check if the feedback channel exists
      if feedback_channel:
          # Send the feedback to the feedback channel
          await feedback_channel.send(f"Suggestion from {ctx.author}: {feedback.content}")
          await ctx.channel.send("Thank you for your suggestion! It has been submitted.")
      else:
          await ctx.channel.send("The suggestion channel does not exist. Please contact the server administrator.")

def setup(bot):
    bot.add_cog(Feedback(bot))