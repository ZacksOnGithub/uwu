import discord
import os
import asyncio
from discord.ext import commands

bot = commands.Bot(intents=discord.Intents.all())

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user}")
    print(f"Bot Latency: {round(bot.latency * 1000)}ms")
    await bot.change_presence(activity=discord.Game(name="m!help | monu.xyz"))

    async def print_bot_latency():
        while not bot.is_closed():
            await asyncio.sleep(60)  # Adjust the interval (in seconds) as needed
            print(f"Bot Latency: {round(bot.latency * 1000)}ms")

    bot.loop.create_task(print_bot_latency())

@bot.event
async def on_guild_join(guild):
    emb = discord.Embed(
        title="Thanks for adding me!",
        description=f"Thanks for adding me to {guild}! If you need any help, please send `m!help`",
        color=discord.Color.green()
    )
    await guild.system_channel.send(embed=emb)

for folder in ["commands", "events"]:
    for file in os.listdir(f"./cogs/{folder}"):
        if file.endswith(".py"):
            bot.load_extension(f"cogs.{folder}.{file[:-3]}")

token = os.environ.get("TOKEN")
bot.run(token)