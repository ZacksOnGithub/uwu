# Monu Discord Bot

If you are seeing this right now this is the official Monu Discord Bot code! If you are here you are either a developer or a person that forked this and will steal all of our commands (Jk)

## Getting Started

When --phibixy-- is not online you will run this replit! Failure to be running the replit will result in a termination as we need active people and willing to do stuff!

## FAQ

If you ever need help about any commands please @ the Monu Core Team for information about commands!